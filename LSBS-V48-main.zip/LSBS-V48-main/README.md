Brawl Stars V48 MOD!

# This is a fork from original BSDS by [Crazor](https://github.com/CrazorTheCat) 

Discord link : https://discord.gg/DAQVzRAxKt

ANDROID (GOOGLE DRIVE) : https://drive.google.com/file/d/1KS09oc5zNtNCgA-O2Q9iTeGMSPVZmHfd/view?usp=drivesdk

Server ZIP: https://codeload.github.com/LekmaDev/LSBS-V48/zip/refs/heads/main

## Requirements: ##
1. a brain...

## How to play LSBS: ##
1. download server and apk
2. install the apk
3. download pydroid (if you want to run from the phone)
4. open in pydroid Core.py located in the server folder
5. click on the run button
6. now open the game and play

## Change the ip address and port (if needed) in libprojectbsds.config.so located in the lib folder of the apk ##

![lsbsv48](https://cdn.discordapp.com/attachments/1040608064681803827/1090261450095874058/Screenshot_2023-03-28-16-09-21-822_com.lsbs.v48888.jpg?ex=670c6f59&is=670b1dd9&hm=024662233c54ffdb6230080e903db2035d0b421dd0dcd8239245b377379db83f&)

## credits ##
[Speigen](https://github.com/SpeigenGit) Android Client

[Crazor](https://github.com/CrazorTheCat) for his zip from [BSDS V44](https://github.com/CrazorTheCat/BSDS-V44)
